<?php
/**
 * Database config variables
 */
/*define("DB_HOST", "sql200.byethost7.com");
define("DB_USER", "b7_15025964");
define("DB_PASSWORD","212521");
define("DB_DATABASE", "b7_15025964_gcm");
*/

define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD","");
define("DB_DATABASE", "gcm");
/*
 * Google Cloud Messaging API Key
 */
define("GOOGLE_API_KEY", "AIzaSyDxulki31a2EonnpUEBQ3npA6vQ0bN7GzA"); // Place your Google API Key
                          
?>